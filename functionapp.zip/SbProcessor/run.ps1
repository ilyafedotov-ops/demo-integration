param($ServiceBusTrigger, $TriggerMetadata)

# Parse message
try { $evt = $ServiceBusTrigger | ConvertFrom-Json -Depth 20 } catch { throw "Message is not valid JSON." }

# MSI login to Azure
Connect-AzAccount -Identity -ErrorAction Stop | Out-Null

$acctName = $env:DEMO_STORAGE_ACCOUNT
if(-not $acctName){ throw "App setting DEMO_STORAGE_ACCOUNT is not set." }
$container = $env:DEMO_STORAGE_CONTAINER
if(-not $container){ $container = "landing" }

# Storage context with MI
$ctx = New-AzStorageContext -StorageAccountName $acctName -UseConnectedAccount

# Ensure container exists
$null = Get-AzStorageContainer -Context $ctx -Name $container -ErrorAction SilentlyContinue
if(-not $?){
  New-AzStorageContainer -Name $container -Context $ctx | Out-Null
}

# Build blob path: vendors/yyyy/MM/dd/{VendorAccount}-{ticks}.json
$dtUtc = Get-Date -AsUTC
$folder = "vendors/{0}" -f $dtUtc.ToString("yyyy/MM/dd")
$fname  = "{0}-{1}.json" -f $evt.data.VendorAccount, $dtUtc.Ticks
$blobPath = "$folder/$fname"

# Serialize and upload (via temp file to avoid module differences)
$content = $evt | ConvertTo-Json -Depth 20
$tmp = Join-Path $env:TEMP ("{0}.json" -f [guid]::NewGuid())
Set-Content -Path $tmp -Value $content -Encoding UTF8

Set-AzStorageBlobContent -File $tmp -Container $container -Blob $blobPath -Context $ctx -Force | Out-Null
Remove-Item $tmp -Force -ErrorAction SilentlyContinue
