param($Request, $TriggerMetadata, $sbOut)

# -- Basic validation of required fields
$bodyRaw = $Request.Body
try { $payload = $bodyRaw | ConvertFrom-Json -Depth 20 } catch { $payload = $null }

$required = @('VendorAccount','Name','Currency','CountryRegionId')
$missing  = @()
foreach($r in $required){ if(-not $payload.$r){ $missing += $r } }

if(-not $payload -or $missing.Count -gt 0){
  $msg = @{ error = "Invalid payload"; missing = $missing } | ConvertTo-Json
  Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{ StatusCode = 400; Body = $msg })
  return
}

# -- Enrich (if payload came directly without Logic App)
if(-not $payload.meta){
  $payload = [pscustomobject]@{
    type    = "vendor"
    version = "1.0"
    data    = $payload
    meta    = @{
      source        = "function-http"
      receivedAtUtc = (Get-Date).ToUniversalTime().ToString("o")
      messageId     = [guid]::NewGuid().ToString()
    }
  }
}

# -- Enqueue to Service Bus
$sbOut = $payload | ConvertTo-Json -Depth 20
Push-OutputBinding -Name sbOut -Value $sbOut

# -- 202 Accepted
$resp = [HttpResponseContext]@{
  StatusCode = 202
  Body       = @{
    enqueued = $true
    id       = $payload.meta.messageId
  }
}
Push-OutputBinding -Name Response -Value $resp
