@{
  'Az.Accounts' = '>= 2.12.0'
  'Az.Storage'  = '>= 5.4.0'
}
