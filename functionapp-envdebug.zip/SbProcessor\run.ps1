param($ServiceBusTrigger, $TriggerMetadata)

Write-Host "============================================"
Write-Host "SbProcessor triggered at $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
Write-Host "============================================"

# Parse message - handle both string and object
Write-Host "STEP 1: Parsing message..."
if ($ServiceBusTrigger -is [string]) {
    Write-Host "  Message is string, converting from JSON..."
    try { 
        $evt = $ServiceBusTrigger | ConvertFrom-Json -Depth 20 
        Write-Host "  [OK] Message parsed successfully" -ForegroundColor Green
    } 
    catch { 
        Write-Host "  [ERROR] Message is not valid JSON: $_" -ForegroundColor Red
        throw "Message is not valid JSON." 
    }
} else {
    Write-Host "  Message is already an object"
    $evt = $ServiceBusTrigger
}

Write-Host "  Type: $($evt.type), Vendor: $($evt.data.VendorAccount)"

Write-Host "`nSTEP 2: Reading configuration..."
$acctName = $env:DEMO_STORAGE_ACCOUNT
if(-not $acctName){ 
    Write-Host "  [ERROR] DEMO_STORAGE_ACCOUNT not set" -ForegroundColor Red
    throw "App setting DEMO_STORAGE_ACCOUNT is not set." 
}
$container = $env:DEMO_STORAGE_CONTAINER
if(-not $container){ $container = "landing" }

Write-Host "  Storage Account: $acctName" -ForegroundColor Gray
Write-Host "  Container: $container" -ForegroundColor Gray
Write-Host "  [OK] Configuration loaded" -ForegroundColor Green

# Get storage connection string
Write-Host "`nSTEP 3: Getting storage connection..."

# Debug: Show all DEMO_ variables
Write-Host "  DEBUG: Checking environment variables..." -ForegroundColor Gray
Get-ChildItem Env: | Where-Object { $_.Name -like "DEMO*" -or $_.Name -like "*STORAGE*" } | ForEach-Object {
    Write-Host "    $($_.Name) = $(if($_.Value.Length -gt 50){$_.Value.Substring(0,50)+'...'}else{$_.Value})" -ForegroundColor DarkGray
}

# Try multiple sources
$connString = $env:DEMO_STORAGE_CONNECTION
if(-not $connString){ 
    Write-Host "  DEMO_STORAGE_CONNECTION not found, trying AzureWebJobsStorage..." -ForegroundColor Yellow
    $connString = $env:AzureWebJobsStorage
}

if(-not $connString){ 
    Write-Host "  [ERROR] No storage connection string found" -ForegroundColor Red
    throw "No storage connection string available." 
}

Write-Host "  [OK] Connection string loaded (length: $($connString.Length) chars)" -ForegroundColor Green

# Build blob path: vendors/yyyy/MM/dd/{VendorAccount}-{ticks}.json
Write-Host "`nSTEP 4: Building blob path..."
$dtUtc = [DateTime]::UtcNow
$folder = "vendors/{0:yyyy/MM/dd}" -f $dtUtc
$fname  = "{0}-{1}.json" -f $evt.data.VendorAccount, $dtUtc.Ticks
$blobPath = "$folder/$fname"

Write-Host "  Folder: $folder" -ForegroundColor Gray
Write-Host "  Filename: $fname" -ForegroundColor Gray
Write-Host "  Full path: $blobPath" -ForegroundColor Gray
Write-Host "  [OK] Blob path created" -ForegroundColor Green

# Serialize content
Write-Host "`nSTEP 5: Serializing content..."
$content = $evt | ConvertTo-Json -Depth 20
$bytes = [System.Text.Encoding]::UTF8.GetBytes($content)
Write-Host "  Content size: $($bytes.Length) bytes" -ForegroundColor Gray
Write-Host "  [OK] Content serialized" -ForegroundColor Green

# Upload using Azure CLI (simple and reliable)
Write-Host "`nSTEP 6: Uploading to blob storage..."
$tempFile = [System.IO.Path]::GetTempFileName()
$content | Out-File -FilePath $tempFile -Encoding UTF8 -NoNewline
Write-Host "  Temp file: $tempFile" -ForegroundColor Gray
Write-Host "  Blob path: $blobPath" -ForegroundColor Gray

try {
    Write-Host "  Uploading via Azure Storage..." -ForegroundColor Gray
    
    # Use az storage blob upload
    $uploadResult = az storage blob upload `
        --account-name $acctName `
        --container-name $container `
        --name $blobPath `
        --file $tempFile `
        --connection-string $connString `
        --overwrite `
        -o json 2>&1
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host "  [SUCCESS] Blob uploaded successfully!" -ForegroundColor Green
        Write-Host "  Blob: $blobPath" -ForegroundColor Cyan
    } else {
        throw "Upload failed with exit code $LASTEXITCODE. Output: $uploadResult"
    }
} catch {
    Write-Host "  [ERROR] Upload failed!" -ForegroundColor Red
    Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor Red
    throw
} finally {
    # Clean up temp file
    if (Test-Path $tempFile) {
        Remove-Item $tempFile -Force -ErrorAction SilentlyContinue
    }
}

Write-Host "`n============================================"
Write-Host "SbProcessor completed successfully at $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
Write-Host "============================================"
